//import { useEffect, useState } from "react";
import { useState } from "react";
import { updateEmail } from "../api/estudiantes"; // ajusta la ruta según donde tengas tu función updateEmail
import Swal from "sweetalert2"

export default function UpdateEmail({ studentID, correoActual, onSuccess }) {
    const [correo, setCorreo] = useState(correoActual || "");
    const [cargando, setCargando] = useState(false);
    const [error, setError] = useState(null);
    const [exito, setExito] = useState(false);

    const validarCorreo = (valor) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(valor);
    };

    const manejarSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setExito(false);

        if (!correo.trim()) {

            //setError("El correo no puede estar vacío");
            Swal.fire({
  icon: "error",
  title: "Oops...",
  text: "Digita el correo",
  footer: "El correo no puede estar vacío📬"
});
            return;
        }

        if (!validarCorreo(correo)) {
            setError("El formato del correo no es válido");
            
            return;
        }

        setCargando(true);
        try {
            const estudianteActualizado = await updateEmail(studentID, correo);
            setExito(true);
            if (onSuccess) {
                onSuccess(estudianteActualizado);
            }
        } catch (err) {
            setError(err.message || "Ocurrió un error al actualizar el correo");
        } finally {
            setCargando(false);
        }
    };

    return (
        <form onSubmit={manejarSubmit}>
            <label htmlFor="correo">Correo electrónico</label>
            <input
                id="correo"
                type="email"
                value={correo}
                onChange={(e) => setCorreo(e.target.value)}
                disabled={cargando}
                placeholder="correo@ejemplo.com"
            />

            <button type="submit" disabled={cargando}>
                {cargando ? "Actualizando..." : "Actualizar correo"}
            </button>

            {error && <p style={{ color: "red" }}>{error}</p>}
            {exito && <p style={{ color: "green" }}>Correo actualizado correctamente</p>}
        </form>
    );
}
